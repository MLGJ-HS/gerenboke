<?php
// 启动会话
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 引入数据库连接文件
require_once '../db.php';

// 获取当前操作类型（默认为list）
$action = $_GET['action'] ?? 'list';

// 处理文章删除操作
if ($action === 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    header('Location: posts.php');
    exit;
}

// 处理文章添加/编辑表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    $category_id = $_POST['category_id'] ?? null;
    $id = $_POST['id'] ?? null;
    
    if (empty($title) || empty($content)) {
        $error = '标题和内容不能为空';
    } else {
        if ($id) { // 编辑文章
            $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ?, category_id = ?, update_time = NOW() WHERE id = ?");
            $stmt->execute([$title, $content, $category_id, $id]);
            $success = '文章更新成功';
        } else { // 添加文章
            $stmt = $pdo->prepare("INSERT INTO posts (title, content, category_id, create_time, update_time) VALUES (?, ?, ?, NOW(), NOW())");
            $stmt->execute([$title, $content, $category_id]);
            $success = '文章添加成功';
        }
    }
}

// 获取要编辑的文章信息
$edit_post = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $edit_post = $stmt->fetch();
}

// 获取所有分类
$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC");
$categories_list = $categories->fetchAll();

// 获取所有文章，包括分类名称
$posts = $pdo->query(
    "SELECT p.*, c.name as category_name 
     FROM posts p 
     LEFT JOIN categories c ON p.category_id = c.id 
     ORDER BY p.create_time DESC"
);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>文章管理 - 管理后台</title>
    <!-- 引入 wangEditor -->
    <script src="https://unpkg.com/@wangeditor/editor@latest/dist/index.js"></script>
    <link href="https://unpkg.com/@wangeditor/editor@latest/dist/css/style.css" rel="stylesheet">
    <style>
        /* 继承全局样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        /* 页面头部样式 */
        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }

        .header-actions {
            display: flex;
            gap: 10px;
        }

        /* 按钮样式 */
        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #3699ff;
            color: #fff;
        }

        .btn-primary:hover {
            background: #1a82ff;
        }

        .btn-danger {
            background: #f64e60;
            color: #fff;
        }

        .btn-danger:hover {
            background: #ee2d41;
        }

        /* 表格样式 */
        .table-container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ebedf3;
        }

        .table th {
            background: #f3f6f9;
            color: #181c32;
            font-weight: 500;
        }

        .table tr:hover {
            background: #f8f9fa;
        }

        /* 表单样式 */
        .form-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #181c32;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #e4e6ef;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-control:focus {
            border-color: #3699ff;
            outline: none;
        }

        textarea.form-control {
            min-height: 200px;
            resize: vertical;
        }
        
        /* 警告消息样式 */
        .alert {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .alert-success {
            background-color: #e8fff3;
            color: #50cd89;
            border: 1px solid #9adec1;
        }

        .alert-danger {
            background-color: #fff5f8;
            color: #f1416c;
            border: 1px solid #f1aeb5;
        }
        
        /* 分类标签样式 */
        .category-tag {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            background-color: #f3f6f9;
            color: #3699ff;
            font-size: 12px;
        }
        
        /* 修改表单宽度 */
        .form-group-title, .form-group-category {
            max-width: 600px;
        }
        
        /* wangEditor 编辑器样式 */
        #editor-toolbar {
            border: 1px solid #e4e6ef;
            border-bottom: none;
            border-radius: 4px 4px 0 0;
        }
        
        #editor-container {
            border: 1px solid #e4e6ef;
            border-top: none;
            border-radius: 0 0 4px 4px;
            min-height: 400px;
            max-height: 800px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="header">
                <h1 class="header-title">
                    <?php
                    // 根据操作类型显示不同的标题
                    switch ($action) {
                        case 'add':
                            echo '添加文章';
                            break;
                        case 'edit':
                            echo '编辑文章';
                            break;
                        default:
                            echo '文章管理';
                    }
                    ?>
                </h1>
                <div class="header-actions">
                    <?php if ($action === 'list'): ?>
                        <a href="?action=add" class="btn btn-primary">✚ 添加文章</a>
                    <?php else: ?>
                        <a href="posts.php" class="btn btn-primary">← 返回列表</a>
                    <?php endif; ?>
                </div>
            </header>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if ($action === 'list'): ?>
                <!-- 文章列表 -->
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>标题</th>
                                <th>分类</th>
                                <th>创建时间</th>
                                <th>更新时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($post = $posts->fetch()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($post['id']); ?></td>
                                <td><?php echo htmlspecialchars($post['title']); ?></td>
                                <td>
                                    <?php if ($post['category_name']): ?>
                                        <span class="category-tag"><?php echo htmlspecialchars($post['category_name']); ?></span>
                                    <?php else: ?>
                                        <span class="category-tag" style="color: #999;">未分类</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('Y-m-d H:i', strtotime($post['create_time'])); ?></td>
                                <td><?php echo date('Y-m-d H:i', strtotime($post['update_time'])); ?></td>
                                <td>
                                    <a href="?action=edit&id=<?php echo $post['id']; ?>" class="btn btn-primary">编辑</a>
                                    <a href="?action=delete&id=<?php echo $post['id']; ?>" class="btn btn-danger" onclick="return confirm('确定要删除这篇文章吗？')">删除</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <!-- 添加/编辑文章表单 -->
                <div class="form-container">
                    <form method="post" action="posts.php">
                        <?php if ($edit_post): ?>
                            <input type="hidden" name="id" value="<?php echo $edit_post['id']; ?>">
                        <?php endif; ?>
                        
                        <div class="form-group form-group-title">
                            <label class="form-label" for="title">文章标题</label>
                            <input type="text" id="title" name="title" class="form-control" 
                                value="<?php echo $edit_post ? htmlspecialchars($edit_post['title']) : ''; ?>" required>
                        </div>
                        
                        <div class="form-group form-group-category">
                            <label class="form-label" for="category_id">文章分类</label>
                            <select id="category_id" name="category_id" class="form-control">
                                <option value="">-- 选择分类 --</option>
                                <?php foreach ($categories_list as $category): ?>
                                <option value="<?php echo $category['id']; ?>" 
                                    <?php echo ($edit_post && $edit_post['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="content">文章内容</label>
                            <!-- 富文本编辑器 -->
                            <div id="editor-toolbar"></div>
                            <div id="editor-container"></div>
                            <textarea id="content" name="content" style="display: none;"><?php echo $edit_post ? $edit_post['content'] : ''; ?></textarea>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                <?php echo $edit_post ? '保存修改' : '发布文章'; ?>
                            </button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <!-- wangEditor 初始化 -->
    <script>
    // 文档加载完成后初始化编辑器
    document.addEventListener('DOMContentLoaded', function() {
        try {
            // 初始化富文本编辑器
            const { createEditor, createToolbar } = window.wangEditor;

            const editorConfig = {
                placeholder: '请输入文章内容',
                onChange(editor) {
                    // 当编辑器内容改变时，更新隐藏的textarea
                    const html = editor.getHtml();
                    document.getElementById('content').value = html;
                }
            }

            const editor = createEditor({
                selector: '#editor-container',
                html: document.getElementById('content').value,
                config: editorConfig,
                mode: 'default',
            });

            const toolbarConfig = {
                toolbarKeys: [
                    'headerSelect',
                    'bold',
                    'underline',
                    'italic',
                    '|',
                    'color',
                    'bgColor',
                    '|',
                    'bulletedList',
                    'numberedList',
                    '|',
                    'insertLink',
                    'insertImage',
                    'insertTable',
                    '|',
                    'code',
                    'blockquote',
                    '|',
                    'undo',
                    'redo'
                ]
            }

            const toolbar = createToolbar({
                editor,
                selector: '#editor-toolbar',
                config: toolbarConfig,
                mode: 'default',
            });

            // 表单提交前确保更新富文本内容
            document.querySelector('form').addEventListener('submit', function(e) {
                document.getElementById('content').value = editor.getHtml();
            });
            
            console.log('富文本编辑器初始化成功');
        } catch (error) {
            console.error('富文本编辑器初始化失败:', error);
            // 编辑器加载失败时显示普通textarea
            document.getElementById('content').style.display = 'block';
            document.getElementById('editor-toolbar').style.display = 'none';
            document.getElementById('editor-container').style.display = 'none';
        }
    });
    </script>
</body>
</html> 