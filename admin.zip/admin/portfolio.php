<?php
// 启动会话
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 引入数据库连接文件
require_once '../db.php';

// 获取当前操作类型（默认为list）
$action = $_GET['action'] ?? 'list';

// 处理作品删除操作
if ($action === 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM portfolio WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    header('Location: portfolio.php');
    exit;
}

// 处理作品添加/编辑表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $image_url = $_POST['image_url'] ?? '';
    $id = $_POST['id'] ?? null;
    
    if (empty($title) || empty($description) || empty($image_url)) {
        $error = '标题、描述和图片URL不能为空';
    } else {
        if ($id) { // 编辑作品
            $stmt = $pdo->prepare("UPDATE portfolio SET title = ?, description = ?, image_url = ?, update_time = NOW() WHERE id = ?");
            $stmt->execute([$title, $description, $image_url, $id]);
            $success = '作品更新成功';
        } else { // 添加作品
            $stmt = $pdo->prepare("INSERT INTO portfolio (title, description, image_url, create_time, update_time) VALUES (?, ?, ?, NOW(), NOW())");
            $stmt->execute([$title, $description, $image_url]);
            $success = '作品添加成功';
        }
    }
}

// 获取要编辑的作品信息
$edit_work = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM portfolio WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $edit_work = $stmt->fetch();
}

// 获取所有作品
$works = $pdo->query("SELECT * FROM portfolio ORDER BY create_time DESC");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>作品管理 - 管理后台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <!-- 引入 CKEditor -->
    <script src="https://cdn.ckeditor.com/ckeditor5/36.0.1/classic/ckeditor.js"></script>
    <!-- 引入 wangEditor -->
    <script src="https://unpkg.com/@wangeditor/editor@latest/dist/index.js"></script>
    <link href="https://unpkg.com/@wangeditor/editor@latest/dist/css/style.css" rel="stylesheet">
    <style>
        /* 继承全局样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        /* 页面头部样式 */
        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }

        .header-actions {
            display: flex;
            gap: 10px;
        }

        /* 按钮样式 */
        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #3699ff;
            color: #fff;
        }

        .btn-primary:hover {
            background: #1a82ff;
        }

        .btn-danger {
            background: #f64e60;
            color: #fff;
        }

        .btn-danger:hover {
            background: #ee2d41;
        }

        /* 表格样式 */
        .table-container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ebedf3;
        }

        .table th {
            background: #f3f6f9;
            color: #181c32;
            font-weight: 500;
        }

        .table tr:hover {
            background: #f8f9fa;
        }

        /* 表单样式 */
        .form-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #181c32;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #e4e6ef;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-control:focus {
            border-color: #3699ff;
            outline: none;
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        /* 作品图片预览 */
        .work-preview {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 4px;
        }

        /* 提示框样式 */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background-color: #e8fff3;
            color: #1bc5bd;
            border: 1px solid #1bc5bd;
        }

        .alert-danger {
            background-color: #fff5f8;
            color: #f64e60;
            border: 1px solid #f64e60;
        }

        /* 图片上传样式 */
        .image-upload-container {
            display: flex;
            flex-direction: column;
            gap: 15px;
            max-width: 600px;
        }

        .image-preview {
            width: 100%;
            height: 300px;
            border: 2px dashed #e4e6ef;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background: #f8f9fa;
        }

        .image-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .no-image {
            color: #b5b5c3;
            font-size: 14px;
        }

        .upload-controls {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        /* 富文本编辑器样式 */
        #editor-container {
            border: 1px solid #ccc;
            z-index: 100;
        }
        
        #editor-toolbar {
            border-bottom: 1px solid #ccc;
        }

        .w-e-text-container {
            height: 300px !important;
            background-color: #fff;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="header">
                <h1 class="header-title">
                    <?php
                    // 根据操作类型显示不同的标题
                    switch ($action) {
                        case 'add':
                            echo '添加作品';
                            break;
                        case 'edit':
                            echo '编辑作品';
                            break;
                        default:
                            echo '作品管理';
                    }
                    ?>
                </h1>
                <div class="header-actions">
                    <?php if ($action === 'list'): ?>
                        <a href="?action=add" class="btn btn-primary">✚ 添加作品</a>
                    <?php else: ?>
                        <a href="portfolio.php" class="btn btn-primary">← 返回列表</a>
                    <?php endif; ?>
                </div>
            </header>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if ($action === 'list'): ?>
                <!-- 作品列表 -->
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>图片</th>
                                <th>标题</th>
                                <th>描述</th>
                                <th>创建时间</th>
                                <th>更新时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($work = $works->fetch()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($work['id']); ?></td>
                                <td>
                                    <img src="../<?php echo htmlspecialchars($work['image_url']); ?>" 
                                         alt="<?php echo htmlspecialchars($work['title']); ?>" 
                                         class="work-preview">
                                </td>
                                <td><?php echo htmlspecialchars($work['title']); ?></td>
                                <td><?php echo htmlspecialchars(substr($work['description'], 0, 50)) . '...'; ?></td>
                                <td><?php echo date('Y-m-d H:i', strtotime($work['create_time'])); ?></td>
                                <td><?php echo date('Y-m-d H:i', strtotime($work['update_time'])); ?></td>
                                <td>
                                    <a href="?action=edit&id=<?php echo $work['id']; ?>" class="btn btn-primary">编辑</a>
                                    <a href="?action=delete&id=<?php echo $work['id']; ?>" class="btn btn-danger" onclick="return confirm('确定要删除这个作品吗？')">删除</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <!-- 添加/编辑作品表单 -->
                <div class="form-container">
                    <form method="post" action="portfolio.php">
                        <?php if ($edit_work): ?>
                            <input type="hidden" name="id" value="<?php echo $edit_work['id']; ?>">
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label class="form-label" for="title">作品标题</label>
                            <input type="text" id="title" name="title" class="form-control" 
                                value="<?php echo $edit_work ? htmlspecialchars($edit_work['title']) : ''; ?>" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">作品描述</label>
                            <div id="editor-toolbar"></div>
                            <div id="editor-container"></div>
                            <textarea id="description" name="description" style="display: none;"><?php echo $edit_work ? htmlspecialchars($edit_work['description']) : ''; ?></textarea>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="image_url">作品图片</label>
                            <div class="image-upload-container">
                                <div class="image-preview" id="imagePreview">
                                    <?php if ($edit_work && !empty($edit_work['image_url'])): ?>
                                        <img src="../<?php echo htmlspecialchars($edit_work['image_url']); ?>" alt="预览图">
                                    <?php else: ?>
                                        <div class="no-image">暂无图片</div>
                                    <?php endif; ?>
                                </div>
                                <div class="upload-controls">
                                    <input type="file" id="imageUpload" accept="image/*" style="display: none;">
                                    <button type="button" class="btn btn-primary" onclick="document.getElementById('imageUpload').click()">
                                        <i class="fas fa-upload"></i> 选择图片
                                    </button>
                                    <input type="hidden" id="image_url" name="image_url" 
                                        value="<?php echo $edit_work ? htmlspecialchars($edit_work['image_url']) : ''; ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                <?php echo $edit_work ? '保存修改' : '添加作品'; ?>
                            </button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // 初始化富文本编辑器
    const { createEditor, createToolbar } = window.wangEditor;

    const editorConfig = {
        placeholder: '请输入作品描述',
        onChange(editor) {
            // 当编辑器内容改变时，更新隐藏的textarea
            const html = editor.getHtml();
            document.getElementById('description').value = html;
        }
    }

    const editor = createEditor({
        selector: '#editor-container',
        html: document.getElementById('description').value,
        config: editorConfig,
        mode: 'default',
    });

    const toolbarConfig = {
        toolbarKeys: [
            'headerSelect',
            'bold',
            'underline',
            'italic',
            '|',
            'color',
            'bgColor',
            '|',
            'bulletedList',
            'numberedList',
            '|',
            'insertLink',
            'insertImage',
            '|',
            'undo',
            'redo'
        ]
    }

    const toolbar = createToolbar({
        editor,
        selector: '#editor-toolbar',
        config: toolbarConfig,
        mode: 'default',
    });

    // 表单提交前确保更新富文本内容
    document.querySelector('form').addEventListener('submit', function(e) {
        document.getElementById('description').value = editor.getHtml();
    });

    // 图片上传处理
    document.getElementById('imageUpload').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;

        // 显示上传中状态
        const preview = document.getElementById('imagePreview');
        preview.innerHTML = '<div class="no-image">上传中...</div>';

        // 创建FormData对象
        const formData = new FormData();
        formData.append('image', file);

        // 发送上传请求
        fetch('upload.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // 更新预览图
                preview.innerHTML = `<img src="../${data.url}" alt="预览图">`;
                // 更新隐藏的图片URL输入框
                document.getElementById('image_url').value = data.url;
            } else {
                alert(data.error || '上传失败');
                preview.innerHTML = '<div class="no-image">暂无图片</div>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('上传失败');
            preview.innerHTML = '<div class="no-image">暂无图片</div>';
        });
    });
    </script>
</body>
</html> 