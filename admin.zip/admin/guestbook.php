<?php
// 启动会话
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 引入数据库连接文件
require_once '../db.php';

// 处理删除留言
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM guestbook WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    header('Location: guestbook.php');
    exit;
}

// 处理回复留言
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply']) && isset($_POST['message_id'])) {
    $reply = trim($_POST['reply']);
    $message_id = $_POST['message_id'];
    
    if (!empty($reply)) {
        $stmt = $pdo->prepare("UPDATE guestbook SET reply = ?, reply_time = NOW() WHERE id = ?");
        $stmt->execute([$reply, $message_id]);
        header('Location: guestbook.php');
        exit;
    }
}

// 检查guestbook表是否存在username字段，如果不存在，则添加
try {
    $check_username_column = $pdo->query("SHOW COLUMNS FROM guestbook LIKE 'username'");
    if (!$check_username_column->fetchColumn()) {
        $pdo->exec("ALTER TABLE guestbook ADD COLUMN username VARCHAR(50) NOT NULL AFTER user_id");
        
        // 如果没有username字段，从users表中获取用户名并更新
        $pdo->exec("UPDATE guestbook g 
                   JOIN users u ON g.user_id = u.id 
                   SET g.username = u.username 
                   WHERE g.username IS NULL OR g.username = ''");
    }
} catch (PDOException $e) {
    $error = '数据库结构更新失败: ' . $e->getMessage();
}

// 获取所有留言，按时间倒序排列
$messages = $pdo->query("SELECT * FROM guestbook ORDER BY create_time DESC");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>留言管理 - 管理后台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        /* 继承全局样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        /* 页面头部样式 */
        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }

        /* 留言列表样式 */
        .message-list {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .message-item {
            padding: 20px;
            border-bottom: 1px solid #ebedf3;
            transition: background-color 0.3s;
        }

        .message-item:last-child {
            border-bottom: none;
        }

        .message-item:hover {
            background-color: #f8f9fa;
        }

        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .message-author {
            font-weight: 500;
            color: #181c32;
        }

        .message-time {
            color: #b5b5c3;
            font-size: 14px;
        }

        .message-content {
            margin-bottom: 15px;
            line-height: 1.6;
            color: #464e5f;
        }

        .message-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #3699ff;
            color: #fff;
        }

        .btn-primary:hover {
            background: #1a82ff;
        }

        .btn-danger {
            background: #f64e60;
            color: #fff;
        }

        .btn-danger:hover {
            background: #ee2d41;
        }

        /* 回复框样式 */
        .reply-form {
            margin-top: 15px;
            display: none;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
        }

        .reply-form textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #e4e6ef;
            border-radius: 4px;
            margin-bottom: 10px;
            resize: vertical;
            min-height: 100px;
        }

        .reply-form textarea:focus {
            border-color: #3699ff;
            outline: none;
        }

        .reply-content {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 4px;
            border-left: 3px solid #3699ff;
        }

        .reply-content p {
            margin: 0;
            color: #464e5f;
        }

        .reply-time {
            color: #b5b5c3;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="header">
                <h1 class="header-title">留言管理</h1>
            </header>

            <div class="message-list">
                <?php while ($message = $messages->fetch()): ?>
                <div class="message-item">
                    <div class="message-header">
                        <span class="message-author"><?php echo htmlspecialchars($message['username']); ?></span>
                        <span class="message-time"><?php echo date('Y-m-d H:i', strtotime($message['create_time'])); ?></span>
                    </div>
                    <div class="message-content">
                        <?php echo nl2br(htmlspecialchars($message['content'])); ?>
                    </div>
                    <?php if (!empty($message['reply'])): ?>
                    <div class="reply-content">
                        <p><?php echo nl2br(htmlspecialchars($message['reply'])); ?></p>
                        <div class="reply-time">回复时间：<?php echo date('Y-m-d H:i', strtotime($message['reply_time'])); ?></div>
                    </div>
                    <?php endif; ?>
                    <div class="message-actions">
                        <button class="btn btn-primary" onclick="toggleReplyForm(<?php echo $message['id']; ?>)">
                            <i class="fas fa-reply"></i> 回复
                        </button>
                        <a href="?action=delete&id=<?php echo $message['id']; ?>" class="btn btn-danger" onclick="return confirm('确定要删除这条留言吗？')">
                            <i class="fas fa-trash"></i> 删除
                        </a>
                    </div>
                    <div class="reply-form" id="replyForm<?php echo $message['id']; ?>">
                        <form method="post" action="guestbook.php">
                            <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                            <textarea name="reply" placeholder="请输入回复内容..."><?php echo htmlspecialchars($message['reply'] ?? ''); ?></textarea>
                            <button type="submit" class="btn btn-primary">提交回复</button>
                        </form>
                    </div>
                </div>
                <?php endwhile; ?>
                
                <?php if ($messages->rowCount() === 0): ?>
                <div class="p-4 text-center text-muted">
                    目前还没有任何留言。
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function toggleReplyForm(messageId) {
        const form = document.getElementById('replyForm' + messageId);
        form.style.display = form.style.display === 'none' ? 'block' : 'none';
    }
    </script>
</body>
</html> 