<?php
// 启动会话
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 引入数据库连接文件
require_once '../db.php';

// 处理删除用户
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    header('Location: users.php');
    exit;
}

// 处理修改密码
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $user_id = $_POST['user_id'];
    $new_password = $_POST['new_password'];
    
    if (!empty($new_password)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashed_password, $user_id]);
        $success = "密码修改成功！";
    }
}

// 获取所有用户
$users = $pdo->query("SELECT * FROM users ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户管理 - 管理后台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        /* 继承全局样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        /* 页面头部样式 */
        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }

        /* 用户列表样式 */
        .user-list {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ebedf3;
        }

        .table th {
            background: #f3f6f9;
            color: #181c32;
            font-weight: 500;
        }

        .table tr:hover {
            background: #f8f9fa;
        }

        /* 按钮样式 */
        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #3699ff;
            color: #fff;
        }

        .btn-primary:hover {
            background: #1a82ff;
        }

        .btn-danger {
            background: #f64e60;
            color: #fff;
        }

        .btn-danger:hover {
            background: #ee2d41;
        }

        /* 弹窗样式 */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }

        .modal-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            width: 400px;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-title {
            font-size: 18px;
            color: #181c32;
        }

        .close {
            font-size: 24px;
            color: #b5b5c3;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #181c32;
        }

        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #e4e6ef;
            border-radius: 4px;
            font-size: 14px;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background: #e8fff3;
            color: #1bc5bd;
            border: 1px solid #1bc5bd;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="header">
                <h1 class="header-title">用户管理</h1>
            </header>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <div class="user-list">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>用户名</th>
                            <th>邮箱</th>
                            <th>注册时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = $users->fetch()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($user['create_time'])); ?></td>
                            <td>
                                <button class="btn btn-primary" onclick="showChangePasswordModal(<?php echo $user['id']; ?>)">
                                    <i class="fas fa-key"></i> 修改密码
                                </button>
                                <a href="?action=delete&id=<?php echo $user['id']; ?>" class="btn btn-danger" onclick="return confirm('确定要删除这个用户吗？')">
                                    <i class="fas fa-trash"></i> 删除
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- 修改密码弹窗 -->
    <div id="changePasswordModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">修改密码</h2>
                <span class="close" onclick="hideChangePasswordModal()">&times;</span>
            </div>
            <form method="post" action="users.php">
                <input type="hidden" name="action" value="change_password">
                <input type="hidden" name="user_id" id="changePasswordUserId">
                <div class="form-group">
                    <label class="form-label" for="new_password">新密码</label>
                    <input type="password" id="new_password" name="new_password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">保存修改</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function showChangePasswordModal(userId) {
        document.getElementById('changePasswordModal').style.display = 'block';
        document.getElementById('changePasswordUserId').value = userId;
    }

    function hideChangePasswordModal() {
        document.getElementById('changePasswordModal').style.display = 'none';
    }

    // 点击弹窗外部关闭弹窗
    window.onclick = function(event) {
        const modal = document.getElementById('changePasswordModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
    </script>
</body>
</html> 