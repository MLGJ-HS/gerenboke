<?php
// 启动会话
session_start();

// 检查是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

require_once '../db.php';

// 处理删除操作
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM links WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: links.php?message=删除成功');
    exit;
}

// 处理添加/编辑操作
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $url = isset($_POST['url']) ? trim($_POST['url']) : '';
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    
    if (empty($title) || empty($url)) {
        $error = '请填写所有必填字段';
    } else {
        try {
            if ($id > 0) {
                // 更新现有链接
                $stmt = $pdo->prepare("UPDATE links SET title = ?, url = ? WHERE id = ?");
                $stmt->execute([$title, $url, $id]);
                $message = '链接更新成功';
            } else {
                // 添加新链接
                $stmt = $pdo->prepare("INSERT INTO links (title, url, create_time) VALUES (?, ?, NOW())");
                $stmt->execute([$title, $url]);
                $message = '链接添加成功';
            }
            
            header('Location: links.php?message=' . urlencode($message));
            exit;
        } catch (PDOException $e) {
            $error = '操作失败: ' . $e->getMessage();
        }
    }
}

// 获取要编辑的链接
$editLink = null;
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM links WHERE id = ?");
    $stmt->execute([$id]);
    $editLink = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$editLink) {
        header('Location: links.php?error=' . urlencode('未找到该链接'));
        exit;
    }
}

// 获取所有链接
$stmt = $pdo->query("SELECT * FROM links ORDER BY id DESC");
$links = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 获取管理员用户名
$admin_username = $_SESSION['admin_username'] ?? '管理员';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>友情链接管理 - 管理后台</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info a {
            color: #5c5e81;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            transition: all 0.3s;
        }

        .user-info a:hover {
            background: #f3f6f9;
        }

        .card {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            overflow: hidden;
        }

        .card-header {
            padding: 20px;
            border-bottom: 1px solid #ebedf3;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-title {
            font-size: 18px;
            font-weight: 500;
            color: #181c32;
            margin: 0;
        }

        .card-body {
            padding: 20px;
        }

        .btn {
            display: inline-block;
            font-weight: 400;
            color: #212529;
            text-align: center;
            vertical-align: middle;
            cursor: pointer;
            background-color: transparent;
            border: 1px solid transparent;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5;
            border-radius: 0.25rem;
            transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
            text-decoration: none;
        }

        .btn-primary {
            color: #fff;
            background-color: #3699ff;
            border-color: #3699ff;
        }

        .btn-primary:hover {
            background-color: #187de4;
            border-color: #187de4;
        }

        .btn-secondary {
            color: #212529;
            background-color: #e4e6ef;
            border-color: #e4e6ef;
        }

        .btn-secondary:hover {
            background-color: #d1d3e0;
            border-color: #d1d3e0;
        }

        .btn-danger {
            color: #fff;
            background-color: #f64e60;
            border-color: #f64e60;
        }

        .btn-danger:hover {
            background-color: #ee2d41;
            border-color: #ee2d41;
        }
        
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
            line-height: 1.5;
            border-radius: 0.2rem;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ebedf3;
        }

        .table th {
            font-weight: 500;
            color: #5c5e81;
            background-color: #f3f6f9;
        }

        .table tbody tr:hover {
            background-color: #f9f9f9;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .form-control {
            display: block;
            width: 100%;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #e4e6ef;
            border-radius: 0.25rem;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .form-control:focus {
            color: #495057;
            background-color: #fff;
            border-color: #69b3ff;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(54, 153, 255, 0.25);
        }

        .alert {
            position: relative;
            padding: 0.75rem 1.25rem;
            margin-bottom: 1rem;
            border: 1px solid transparent;
            border-radius: 0.25rem;
        }

        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }

        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="main-content">
            <div class="header">
                <h1 class="header-title">友情链接管理</h1>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($admin_username); ?></span>
                    <a href="logout.php">退出登录</a>
                </div>
            </div>

            <?php if (isset($_GET['message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_GET['message']); ?>
            </div>
            <?php endif; ?>

            <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($_GET['error']); ?>
            </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>

            <!-- 添加/编辑链接表单 -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title"><?php echo $editLink ? '编辑链接' : '添加新链接'; ?></h2>
                </div>
                <div class="card-body">
                    <form action="links.php" method="POST">
                        <?php if ($editLink): ?>
                        <input type="hidden" name="id" value="<?php echo $editLink['id']; ?>">
                        <?php endif; ?>

                        <div class="form-group">
                            <label class="form-label" for="title">链接标题 <span style="color: red;">*</span></label>
                            <input type="text" id="title" name="title" class="form-control" required value="<?php echo $editLink ? htmlspecialchars($editLink['title']) : ''; ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="url">链接地址 <span style="color: red;">*</span></label>
                            <input type="url" id="url" name="url" class="form-control" required value="<?php echo $editLink ? htmlspecialchars($editLink['url']) : ''; ?>">
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary"><?php echo $editLink ? '更新链接' : '添加链接'; ?></button>
                            <?php if ($editLink): ?>
                            <a href="links.php" class="btn btn-secondary">取消</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            <!-- 链接列表 -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">友情链接列表</h2>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th width="5%">ID</th>
                                <th width="30%">链接标题</th>
                                <th width="45%">链接地址</th>
                                <th width="20%">操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($links)): ?>
                            <tr>
                                <td colspan="4" style="text-align: center;">暂无链接</td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($links as $link): ?>
                                <tr>
                                    <td><?php echo $link['id']; ?></td>
                                    <td><?php echo htmlspecialchars($link['title']); ?></td>
                                    <td>
                                        <a href="<?php echo htmlspecialchars($link['url']); ?>" target="_blank">
                                            <?php echo htmlspecialchars($link['url']); ?>
                                        </a>
                                    </td>
                                    <td class="action-buttons">
                                        <a href="links.php?action=edit&id=<?php echo $link['id']; ?>" class="btn btn-sm btn-primary">编辑</a>
                                        <a href="links.php?action=delete&id=<?php echo $link['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定要删除这个链接吗？')">删除</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 