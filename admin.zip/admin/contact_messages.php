<?php
require_once '../db.php';

// 检查管理员登录状态
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 处理标记已读/未读
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    if ($_GET['action'] === 'read') {
        $stmt = $pdo->prepare("UPDATE contact_messages SET is_read = 1 WHERE id = ?");
        $stmt->execute([$id]);
    } elseif ($_GET['action'] === 'unread') {
        $stmt = $pdo->prepare("UPDATE contact_messages SET is_read = 0 WHERE id = ?");
        $stmt->execute([$id]);
    } elseif ($_GET['action'] === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
        $stmt->execute([$id]);
    }
    
    header('Location: contact_messages.php');
    exit;
}

// 获取所有联系表单消息，按创建时间降序排序
$stmt = $pdo->query("SELECT * FROM contact_messages ORDER BY create_time DESC");
$messages = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>联系表单消息管理 - 管理后台</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }
        
        .message-list {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-top: 20px;
        }
        
        .message-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .message-table th, .message-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .message-table th {
            background-color: #f8f8f8;
            font-weight: bold;
            color: #333;
        }
        
        .message-table tr:hover {
            background-color: #f9f9f9;
        }
        
        .message-table .unread {
            font-weight: bold;
            background-color: #f0f8ff;
        }
        
        .actions {
            display: flex;
            gap: 5px;
        }
        
        .action-link {
            padding: 5px 10px;
            background-color: #eee;
            color: #333;
            border-radius: 3px;
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        
        .action-link:hover {
            background-color: #ddd;
        }
        
        .view-link {
            background-color: #e3f2fd;
            color: #0d47a1;
        }
        
        .view-link:hover {
            background-color: #bbdefb;
        }
        
        .read-link {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        
        .read-link:hover {
            background-color: #c8e6c9;
        }
        
        .unread-link {
            background-color: #ede7f6;
            color: #4527a0;
        }
        
        .unread-link:hover {
            background-color: #d1c4e9;
        }
        
        .delete-link {
            background-color: #ffebee;
            color: #c62828;
        }
        
        .delete-link:hover {
            background-color: #ffcdd2;
        }
        
        .message-date {
            font-size: 14px;
            color: #666;
        }
        
        .no-messages {
            padding: 30px;
            text-align: center;
            color: #777;
        }
        
        /* 消息详情弹窗 */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .modal-content {
            background-color: #fff;
            width: 60%;
            max-width: 700px;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .modal-title {
            font-size: 20px;
            color: #333;
            margin: 0;
        }
        
        .close-btn {
            font-size: 24px;
            color: #777;
            cursor: pointer;
            background: none;
            border: none;
        }
        
        .message-info {
            margin-bottom: 20px;
        }
        
        .message-info p {
            margin: 5px 0;
        }
        
        .message-info span {
            font-weight: bold;
            display: inline-block;
            width: 100px;
        }
        
        .message-content {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            white-space: pre-wrap;
            line-height: 1.5;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info a {
            color: #5c5e81;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            transition: all 0.3s;
        }

        .user-info a:hover {
            background: #f3f6f9;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="main-content">
            <div class="header">
                <h1 class="header-title">联系表单消息管理</h1>
                <div class="user-info">
                    <span><?php echo $_SESSION['admin_username'] ?? '管理员'; ?></span>
                    <a href="logout.php">退出登录</a>
                </div>
            </div>
            
            <div class="message-list">
                <?php if (empty($messages)): ?>
                    <div class="no-messages">
                        暂无联系表单消息
                    </div>
                <?php else: ?>
                    <table class="message-table">
                        <thead>
                            <tr>
                                <th style="width: 5%;">ID</th>
                                <th style="width: 15%;">姓名</th>
                                <th style="width: 20%;">邮箱</th>
                                <th style="width: 25%;">主题</th>
                                <th style="width: 15%;">时间</th>
                                <th style="width: 20%;">操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($messages as $msg): ?>
                                <tr class="<?php echo $msg['is_read'] ? '' : 'unread'; ?>">
                                    <td><?php echo $msg['id']; ?></td>
                                    <td><?php echo htmlspecialchars($msg['name']); ?></td>
                                    <td><?php echo htmlspecialchars($msg['email']); ?></td>
                                    <td><?php echo htmlspecialchars($msg['subject']); ?></td>
                                    <td class="message-date"><?php echo date('Y-m-d H:i', strtotime($msg['create_time'])); ?></td>
                                    <td class="actions">
                                        <a href="javascript:void(0)" onclick="showMessage(<?php echo $msg['id']; ?>)" class="action-link view-link">查看</a>
                                        <?php if ($msg['is_read']): ?>
                                            <a href="contact_messages.php?action=unread&id=<?php echo $msg['id']; ?>" class="action-link unread-link">标为未读</a>
                                        <?php else: ?>
                                            <a href="contact_messages.php?action=read&id=<?php echo $msg['id']; ?>" class="action-link read-link">标为已读</a>
                                        <?php endif; ?>
                                        <a href="contact_messages.php?action=delete&id=<?php echo $msg['id']; ?>" class="action-link delete-link" onclick="return confirm('确定要删除这条消息吗？')">删除</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- 消息详情弹窗 -->
    <div id="messageModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">消息详情</h2>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <div id="messageDetail"></div>
        </div>
    </div>
    
    <script>
        // 消息弹窗相关功能
        var modal = document.getElementById('messageModal');
        
        function showMessage(id) {
            // 在实际应用中，应该使用AJAX获取消息详情
            <?php 
            $messageDetails = [];
            foreach ($messages as $msg) {
                $messageDetails[$msg['id']] = [
                    'name' => htmlspecialchars($msg['name']),
                    'email' => htmlspecialchars($msg['email']),
                    'subject' => htmlspecialchars($msg['subject']),
                    'message' => htmlspecialchars($msg['message']),
                    'create_time' => date('Y-m-d H:i:s', strtotime($msg['create_time']))
                ];
            }
            echo 'var messageDetails = ' . json_encode($messageDetails) . ';';
            ?>
            
            var detail = messageDetails[id];
            if (detail) {
                var detailHTML = '<div class="message-info">';
                detailHTML += '<p><span>发送人：</span>' + detail.name + '</p>';
                detailHTML += '<p><span>邮箱：</span>' + detail.email + '</p>';
                detailHTML += '<p><span>主题：</span>' + detail.subject + '</p>';
                detailHTML += '<p><span>时间：</span>' + detail.create_time + '</p>';
                detailHTML += '</div>';
                detailHTML += '<div class="message-content">' + detail.message + '</div>';
                
                document.getElementById('messageDetail').innerHTML = detailHTML;
                modal.style.display = 'flex';
                
                // 标记为已读
                fetch('contact_messages.php?action=read&id=' + id, {method: 'GET'});
            }
        }
        
        function closeModal() {
            modal.style.display = 'none';
        }
        
        // 点击弹窗外部关闭弹窗
        window.onclick = function(event) {
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html> 
</html> 
