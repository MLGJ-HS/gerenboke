<?php
// 启动会话
session_start();

// 检查是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 获取管理员用户名
$admin_username = $_SESSION['admin_username'] ?? '管理员';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台</title>
    <!-- 引入Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .admin-sidebar {
            width: 240px;
            background-color: #1e1e2d;
            color: #a2a3b7;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
        }

        .logo {
            padding: 20px;
            color: #fff;
            font-size: 20px;
            font-weight: bold;
            border-bottom: 1px solid #2e2e40;
            margin-bottom: 20px;
        }

        .menu-section {
            padding: 10px 0;
        }

        .menu-title {
            padding: 10px 25px;
            font-size: 12px;
            text-transform: uppercase;
            color: #5c5e81;
            font-weight: 500;
        }

        .menu-items {
            list-style: none;
        }

        .menu-item {
            padding: 8px 25px;
            display: flex;
            align-items: center;
            color: #a2a3b7;
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
        }

        .menu-item:hover,
        .menu-item.active {
            color: #fff;
            background: #1b1b28;
        }

        .menu-item.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 4px;
            background: #3699ff;
        }

        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info a {
            color: #5c5e81;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            transition: all 0.3s;
        }

        .user-info a:hover {
            background: #f3f6f9;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .stat-number {
            font-size: 28px;
            font-weight: bold;
            color: #181c32;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #b5b5c3;
            font-size: 13px;
            text-transform: uppercase;
        }

        .charts-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }

        .chart-card {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            height: 400px;
            display: flex;
            flex-direction: column;
        }

        .chart-title {
            font-size: 16px;
            font-weight: 500;
            color: #181c32;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ebedf3;
        }

        .chart-container {
            flex: 1;
            position: relative;
            min-height: 300px;
        }

        .recent-activity {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .activity-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .activity-title {
            font-size: 16px;
            font-weight: 500;
            color: #181c32;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            padding: 15px 0;
            border-bottom: 1px solid #ebedf3;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .activity-item:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="header">
                <h1 class="header-title">控制面板</h1>
                <div class="user-info">
                    <span>欢迎，<?php echo htmlspecialchars($admin_username); ?></span>
                    <a href="logout.php">退出登录</a>
                </div>
            </header>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number">8</div>
                    <div class="stat-label">文章总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">12</div>
                    <div class="stat-label">作品总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">5</div>
                    <div class="stat-label">评论总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">20</div>
                    <div class="stat-label">用户总数</div>
                </div>
            </div>

            <div class="charts-grid">
                <div class="chart-card">
                    <h3 class="chart-title">访问统计</h3>
                    <div class="chart-container">
                        <canvas id="visitsChart"></canvas>
                    </div>
                </div>
                <div class="chart-card">
                    <h3 class="chart-title">文章分类统计</h3>
                    <div class="chart-container">
                        <canvas id="categoriesChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="recent-activity">
                <div class="activity-header">
                    <h2 class="activity-title">最近活动</h2>
                </div>
                <ul class="activity-list">
                    <li class="activity-item">
                        <span>新文章发布：《PHP开发技巧分享》</span>
                        <span>2024-01-20</span>
                    </li>
                    <li class="activity-item">
                        <span>新用户注册：张三</span>
                        <span>2024-01-19</span>
                    </li>
                    <li class="activity-item">
                        <span>系统更新：版本1.2.0</span>
                        <span>2024-01-18</span>
                    </li>
                </ul>
            </div>
        </main>
    </div>

    <script>
        // 访问统计图表
        const visitsCtx = document.getElementById('visitsChart').getContext('2d');
        new Chart(visitsCtx, {
            type: 'line',
            data: {
                labels: ['1月', '2月', '3月', '4月', '5月', '6月', '7月'],
                datasets: [{
                    label: '访问量',
                    data: [65, 59, 80, 81, 56, 55, 40],
                    fill: true,
                    backgroundColor: 'rgba(54, 153, 255, 0.1)',
                    borderColor: '#3699ff',
                    tension: 0.4,
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#3699ff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: '#1e1e2d',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        padding: 10,
                        displayColors: false
                    }
                }
            }
        });

        // 文章分类统计图表
        const categoriesCtx = document.getElementById('categoriesChart').getContext('2d');
        new Chart(categoriesCtx, {
            type: 'doughnut',
            data: {
                labels: ['技术', '生活', '随笔', '其他'],
                datasets: [{
                    data: [12, 19, 3, 5],
                    backgroundColor: [
                        '#3699ff',
                        '#1bc5bd',
                        '#ffa800',
                        '#f64e60'
                    ],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '75%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: '#1e1e2d',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        padding: 10,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html> 