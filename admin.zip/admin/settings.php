<?php
// 启动会话
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 引入数据库连接文件
require_once '../db.php';

// 处理设置更新
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings = [
        'site_name' => $_POST['site_name'],
        'site_description' => $_POST['site_description'],
        'site_keywords' => $_POST['site_keywords'],
        'site_email' => $_POST['site_email'],
        'site_phone' => $_POST['site_phone'],
        'site_address' => $_POST['site_address'],
        'site_icp' => $_POST['site_icp'],
        'site_copyright' => $_POST['site_copyright'],
        'wechat_qrcode' => $_POST['wechat_qrcode'],
        'weibo_name' => $_POST['weibo_name']
    ];

    // 更新每个设置
    foreach ($settings as $key => $value) {
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) 
                              ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$key, $value, $value]);
    }

    $success = "设置已成功更新！";
}

// 获取当前设置
$settings = [];
$stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
while ($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

// 设置默认值
$default_settings = [
    'site_name' => '个人博客',
    'site_description' => '分享技术，记录生活',
    'site_keywords' => '博客,技术,生活',
    'site_email' => 'contact@example.com',
    'site_phone' => '(123) 456-7890',
    'site_address' => '中国上海市',
    'site_icp' => '沪ICP备12345678号',
    'site_copyright' => '© 2024 个人博客. All Rights Reserved.',
    'wechat_qrcode' => 'web-design',
    'weibo_name' => '@web设计'
];

// 合并默认值和数据库值
$settings = array_merge($default_settings, $settings);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>网站设置 - 管理后台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        /* 继承全局样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        /* 页面头部样式 */
        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }

        /* 设置表单样式 */
        .settings-form {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            padding: 30px;
        }

        .form-section {
            margin-bottom: 40px;
        }

        .section-title {
            font-size: 18px;
            color: #181c32;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f3f6f9;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #181c32;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #e4e6ef;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-control:focus {
            border-color: #3699ff;
            outline: none;
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #3699ff;
            color: #fff;
        }

        .btn-primary:hover {
            background: #1a82ff;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background: #e8fff3;
            color: #1bc5bd;
            border: 1px solid #1bc5bd;
        }

        /* 响应式布局 */
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="header">
                <h1 class="header-title">网站设置</h1>
            </header>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <form class="settings-form" method="post" action="settings.php">
                <div class="form-section">
                    <h2 class="section-title">基本信息设置</h2>
                    <div class="form-group">
                        <label class="form-label" for="site_name">网站名称</label>
                        <input type="text" id="site_name" name="site_name" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="site_description">网站描述</label>
                        <textarea id="site_description" name="site_description" class="form-control"><?php echo htmlspecialchars($settings['site_description']); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="site_keywords">网站关键词</label>
                        <input type="text" id="site_keywords" name="site_keywords" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_keywords']); ?>">
                    </div>
                </div>

                <div class="form-section">
                    <h2 class="section-title">联系方式设置</h2>
                    <div class="form-group">
                        <label class="form-label" for="site_email">联系邮箱</label>
                        <input type="email" id="site_email" name="site_email" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_email']); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="site_phone">联系电话</label>
                        <input type="text" id="site_phone" name="site_phone" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_phone']); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="site_address">联系地址</label>
                        <input type="text" id="site_address" name="site_address" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_address']); ?>">
                    </div>
                </div>

                <div class="form-section">
                    <h2 class="section-title">社交媒体设置</h2>
                    <div class="form-group">
                        <label class="form-label" for="wechat_qrcode">微信公众号</label>
                        <input type="text" id="wechat_qrcode" name="wechat_qrcode" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['wechat_qrcode']); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="weibo_name">新浪微博</label>
                        <input type="text" id="weibo_name" name="weibo_name" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['weibo_name']); ?>">
                    </div>
                </div>

                <div class="form-section">
                    <h2 class="section-title">其他设置</h2>
                    <div class="form-group">
                        <label class="form-label" for="site_icp">ICP备案号</label>
                        <input type="text" id="site_icp" name="site_icp" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_icp']); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="site_copyright">版权信息</label>
                        <input type="text" id="site_copyright" name="site_copyright" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_copyright']); ?>">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> 保存设置
                </button>
            </form>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 