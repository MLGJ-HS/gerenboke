<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">管理后台</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../" target="_blank">查看网站</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">退出登录</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<style>
body {
    padding-top: 56px;
}
</style> 