<?php
// 获取当前页面文件名，用于高亮当前菜单项
$current_page = basename($_SERVER['PHP_SELF']);
?>
<style>
    .admin-sidebar {
        width: 240px;
        background-color: #1e1e2d;
        color: #a2a3b7;
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        overflow-y: auto;
    }

    .logo {
        padding: 20px;
        color: #fff;
        font-size: 20px;
        font-weight: bold;
        border-bottom: 1px solid #2e2e40;
        margin-bottom: 20px;
    }

    .menu-section {
        padding: 10px 0;
    }

    .menu-title {
        padding: 10px 25px;
        font-size: 12px;
        text-transform: uppercase;
        color: #5c5e81;
        font-weight: 500;
    }

    .menu-items {
        list-style: none;
    }

    .menu-item {
        padding: 8px 25px;
        display: flex;
        align-items: center;
        color: #a2a3b7;
        text-decoration: none;
        transition: all 0.3s;
        position: relative;
    }

    .menu-item i {
        margin-right: 10px;
        font-size: 16px;
    }

    .menu-item:hover,
    .menu-item.active {
        color: #fff;
        background: #1b1b28;
    }

    .menu-item.active::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 4px;
        background: #3699ff;
    }

    .submenu {
        padding-left: 35px;
        display: none;
    }

    .menu-item.expanded .submenu {
        display: block;
    }

    .submenu .menu-item {
        padding: 8px 15px;
        font-size: 13px;
    }
</style>

<aside class="admin-sidebar">
    <div class="logo">MYBLOG</div>
    <div class="menu-section">
        <div class="menu-title">主要功能</div>
        <nav class="menu-items">
            <a href="index.php" class="menu-item <?php echo $current_page === 'index.php' ? 'active' : ''; ?>">
                📊 控制面板
            </a>
            <a href="categories.php" class="menu-item <?php echo $current_page === 'categories.php' ? 'active' : ''; ?>">
                📁 分类管理
            </a>
            <a href="posts.php" class="menu-item <?php echo $current_page === 'posts.php' ? 'active' : ''; ?>">
                📝 文章管理
                <div class="submenu">
                    <a href="posts.php?action=list" class="menu-item">文章列表</a>
                    <a href="posts.php?action=add" class="menu-item">添加文章</a>
                </div>
            </a>
           
            <a href="portfolio.php" class="menu-item <?php echo $current_page === 'portfolio.php' ? 'active' : ''; ?>">
                🎨 作品管理
            </a>
            <a href="comments.php" class="menu-item <?php echo $current_page === 'comments.php' ? 'active' : ''; ?>">
                💬 评论管理
            </a>
            <a href="guestbook.php" class="menu-item <?php echo $current_page === 'guestbook.php' ? 'active' : ''; ?>">
                📒 留言管理
            </a>
            <a href="contact_messages.php" class="menu-item <?php echo $current_page === 'contact_messages.php' ? 'active' : ''; ?>">
                📧 联系表单消息
            </a>
            <a href="links.php" class="menu-item <?php echo $current_page === 'links.php' ? 'active' : ''; ?>">
                🔗 友情链接管理
            </a>
          
        </nav>
    </div>
    <div class="menu-section">
        <div class="menu-title">系统管理</div>
        <nav class="menu-items">
            <a href="users.php" class="menu-item <?php echo $current_page === 'users.php' ? 'active' : ''; ?>">
                👥 用户管理
            </a>
           
        </nav>
    </div>
</aside>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 为带有子菜单的菜单项添加点击事件
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(item => {
        if (item.querySelector('.submenu')) {
            item.addEventListener('click', function(e) {
                if (e.target === item) {
                    e.preventDefault();
                    this.classList.toggle('expanded');
                }
            });
        }
    });
});
</script> 