<div class="sidebar bg-light border-end">
    <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action">
            <i class="fas fa-tachometer-alt"></i> 仪表盘
        </a>
        <a href="posts.php" class="list-group-item list-group-item-action">
            <i class="fas fa-file-alt"></i> 文章管理
        </a>
        <a href="works.php" class="list-group-item list-group-item-action">
            <i class="fas fa-briefcase"></i> 作品管理
        </a>
        <a href="comments.php" class="list-group-item list-group-item-action">
            <i class="fas fa-comments"></i> 评论管理
        </a>
        
    </div>
</div>
<style>
.sidebar {
    position: fixed;
    top: 56px;
    bottom: 0;
    left: 0;
    width: 200px;
    overflow-y: auto;
}
.sidebar .list-group-item {
    border: none;
    padding: 12px 20px;
}
.sidebar .list-group-item i {
    margin-right: 10px;
    width: 20px;
    text-align: center;
}
.main-content {
    margin-left: 200px;
    padding: 20px;
}
</style> 