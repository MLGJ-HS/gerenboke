<?php
// 启动会话
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 引入数据库连接文件
require_once '../db.php';

// 初始化变量
$edit_mode = false;
$category = [
    'id' => '',
    'name' => '',
    'description' => ''
];

// 如果是编辑模式，获取分类信息
if (isset($_GET['id'])) {
    $edit_mode = true;
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $category = $stmt->fetch();
    
    if (!$category) {
        header('Location: categories.php');
        exit;
    }
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    
    if (empty($name)) {
        $error = '分类名称不能为空';
    } else {
        if ($edit_mode) {
            // 更新分类
            $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ? WHERE id = ?");
            $stmt->execute([$name, $description, $category['id']]);
            $success = '分类更新成功';
        } else {
            // 添加分类
            $stmt = $pdo->prepare("INSERT INTO categories (name, description, create_time) VALUES (?, ?, NOW())");
            $stmt->execute([$name, $description]);
            $success = '分类添加成功';
        }
        
        // 重定向回分类列表页面
        header('Location: categories.php?success=' . urlencode($success));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $edit_mode ? '编辑' : '新增'; ?>分类 - 管理后台</title>
    <style>
        /* 继承全局样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        /* 页面头部样式 */
        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }
        
        /* 按钮样式 */
        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #3699ff;
            color: #fff;
        }

        .btn-primary:hover {
            background: #1a82ff;
        }

        .btn-danger {
            background: #f64e60;
            color: #fff;
        }

        .btn-danger:hover {
            background: #ee2d41;
        }
        
        /* 表单样式 */
        .form-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .form-title {
            font-size: 18px;
            margin-bottom: 20px;
            color: #181c32;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #464e5f;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #e4e6ef;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-control:focus {
            border-color: #3699ff;
            outline: none;
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        /* 提示信息样式 */
        .alert {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .alert-success {
            background-color: #e8fff3;
            color: #50cd89;
            border: 1px solid #9adec1;
        }

        .alert-danger {
            background-color: #fff5f8;
            color: #f1416c;
            border: 1px solid #f1aeb5;
        }
        
        .form-actions {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="header">
                <h1 class="header-title"><?php echo $edit_mode ? '编辑' : '新增'; ?>分类</h1>
            </header>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="form-container">
                <form method="post" action="">
                    <?php if ($edit_mode): ?>
                        <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label class="form-label" for="name">分类名称</label>
                        <input type="text" id="name" name="name" class="form-control" value="<?php echo htmlspecialchars($category['name']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="description">分类描述</label>
                        <textarea id="description" name="description" class="form-control"><?php echo htmlspecialchars($category['description']); ?></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <?php echo $edit_mode ? '保存修改' : '添加分类'; ?>
                        </button>
                        <a href="categories.php" class="btn btn-danger">取消</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html> 