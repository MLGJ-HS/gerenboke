<?php
// 启动会话
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 引入数据库连接文件
require_once '../db.php';

// 处理删除评论
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    header('Location: comments.php');
    exit;
}

// 处理回复评论
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply']) && isset($_POST['comment_id'])) {
    $reply = trim($_POST['reply']);
    $comment_id = $_POST['comment_id'];
    
    if (!empty($reply)) {
        $stmt = $pdo->prepare("UPDATE comments SET reply = ?, reply_time = NOW() WHERE id = ?");
        $stmt->execute([$reply, $comment_id]);
        header('Location: comments.php');
        exit;
    }
}

// 获取所有评论，按时间倒序排列
$comments = $pdo->query("SELECT * FROM comments ORDER BY create_time DESC");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>评论管理 - 管理后台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        /* 继承全局样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        /* 页面头部样式 */
        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }

        /* 评论列表样式 */
        .comment-list {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .comment-item {
            padding: 20px;
            border-bottom: 1px solid #ebedf3;
            transition: background-color 0.3s;
        }

        .comment-item:last-child {
            border-bottom: none;
        }

        .comment-item:hover {
            background-color: #f8f9fa;
        }

        .comment-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .comment-author {
            font-weight: 500;
            color: #181c32;
        }

        .comment-time {
            color: #b5b5c3;
            font-size: 14px;
        }

        .comment-content {
            margin-bottom: 15px;
            line-height: 1.6;
            color: #464e5f;
        }

        .comment-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #3699ff;
            color: #fff;
        }

        .btn-primary:hover {
            background: #1a82ff;
        }

        .btn-danger {
            background: #f64e60;
            color: #fff;
        }

        .btn-danger:hover {
            background: #ee2d41;
        }

        /* 回复框样式 */
        .reply-form {
            margin-top: 15px;
            display: none;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
        }

        .reply-form textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #e4e6ef;
            border-radius: 4px;
            margin-bottom: 10px;
            resize: vertical;
            min-height: 100px;
        }

        .reply-form textarea:focus {
            border-color: #3699ff;
            outline: none;
        }

        .reply-content {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 4px;
            border-left: 3px solid #3699ff;
        }

        .reply-content p {
            margin: 0;
            color: #464e5f;
        }

        .reply-time {
            color: #b5b5c3;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="header">
                <h1 class="header-title">评论管理</h1>
            </header>

            <div class="comment-list">
                <?php while ($comment = $comments->fetch()): ?>
                <div class="comment-item">
                    <div class="comment-header">
                        <span class="comment-author"><?php echo htmlspecialchars($comment['author']); ?></span>
                        <span class="comment-time"><?php echo date('Y-m-d H:i', strtotime($comment['create_time'])); ?></span>
                    </div>
                    <div class="comment-content">
                        <?php echo nl2br(htmlspecialchars($comment['content'])); ?>
                    </div>
                    <?php if (!empty($comment['reply'])): ?>
                    <div class="reply-content">
                        <p><?php echo nl2br(htmlspecialchars($comment['reply'])); ?></p>
                        <div class="reply-time">回复时间：<?php echo date('Y-m-d H:i', strtotime($comment['reply_time'])); ?></div>
                    </div>
                    <?php endif; ?>
                    <div class="comment-actions">
                        <button class="btn btn-primary" onclick="toggleReplyForm(<?php echo $comment['id']; ?>)">
                            <i class="fas fa-reply"></i> 回复
                        </button>
                        <a href="?action=delete&id=<?php echo $comment['id']; ?>" class="btn btn-danger" onclick="return confirm('确定要删除这条评论吗？')">
                            <i class="fas fa-trash"></i> 删除
                        </a>
                    </div>
                    <div class="reply-form" id="replyForm<?php echo $comment['id']; ?>">
                        <form method="post" action="comments.php">
                            <input type="hidden" name="comment_id" value="<?php echo $comment['id']; ?>">
                            <textarea name="reply" placeholder="请输入回复内容..."><?php echo htmlspecialchars($comment['reply'] ?? ''); ?></textarea>
                            <button type="submit" class="btn btn-primary">提交回复</button>
                        </form>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function toggleReplyForm(commentId) {
        const form = document.getElementById('replyForm' + commentId);
        form.style.display = form.style.display === 'none' ? 'block' : 'none';
    }
    </script>
</body>
</html> 