<?php
// 启动会话
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 引入数据库连接文件
require_once '../db.php';

// 处理删除分类
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    header('Location: categories.php?success=' . urlencode('分类删除成功'));
    exit;
}

// 获取所有分类
$categories = $pdo->query("SELECT * FROM categories ORDER BY id ASC");

// 获取成功消息
$success = isset($_GET['success']) ? $_GET['success'] : null;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分类管理 - 管理后台</title>
    <style>
        /* 继承全局样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background-color: #f5f6fa;
            color: #333;
            min-height: 100vh;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .main-content {
            flex: 1;
            margin-left: 240px;
            padding: 20px;
        }

        /* 页面头部样式 */
        .header {
            background: #fff;
            padding: 20px;
            margin: -20px -20px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .header-title {
            font-size: 24px;
            color: #181c32;
        }

        /* 按钮样式 */
        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .btn-primary {
            background: #3699ff;
            color: #fff;
        }

        .btn-primary:hover {
            background: #1a82ff;
        }

        .btn-danger {
            background: #f64e60;
            color: #fff;
        }

        .btn-danger:hover {
            background: #ee2d41;
        }

        /* 表格样式 */
        .table-container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            overflow: hidden;
            margin-bottom: 20px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ebedf3;
        }

        .table th {
            background: #f3f6f9;
            color: #181c32;
            font-weight: 500;
        }

        .table tr:hover {
            background: #f8f9fa;
        }
        
        /* 表单样式 */
        .form-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .form-title {
            font-size: 18px;
            margin-bottom: 20px;
            color: #181c32;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #464e5f;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #e4e6ef;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-control:focus {
            border-color: #3699ff;
            outline: none;
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        /* 提示信息样式 */
        .alert {
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .alert-success {
            background-color: #e8fff3;
            color: #50cd89;
            border: 1px solid #9adec1;
        }

        .alert-danger {
            background-color: #fff5f8;
            color: #f1416c;
            border: 1px solid #f1aeb5;
        }
        
        .header-actions {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="header">
                <h1 class="header-title">分类管理</h1>
                <div class="header-actions">
                    <a href="category_form.php" class="btn btn-primary">➕ 新增分类</a>
                </div>
            </header>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <!-- 分类列表 -->
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>分类名称</th>
                            <th>描述</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($category = $categories->fetch()): ?>
                        <tr>
                            <td><?php echo $category['id']; ?></td>
                            <td><?php echo htmlspecialchars($category['name']); ?></td>
                            <td><?php echo htmlspecialchars($category['description']); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($category['create_time'])); ?></td>
                            <td>
                                <a href="category_form.php?id=<?php echo $category['id']; ?>" class="btn btn-primary">编辑</a>
                                <a href="?action=delete&id=<?php echo $category['id']; ?>" class="btn btn-danger" onclick="return confirm('确定要删除这个分类吗？')">删除</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if ($categories->rowCount() === 0): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 30px;">暂无分类数据</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html> 