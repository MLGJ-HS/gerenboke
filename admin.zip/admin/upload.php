<?php
// 启动会话
session_start();

// 检查管理员是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Content-Type: application/json');
    echo json_encode(['error' => '未授权访问']);
    exit;
}

// 检查是否有文件上传
if (!isset($_FILES['image'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => '没有文件被上传']);
    exit;
}

$file = $_FILES['image'];

// 检查文件上传错误
if ($file['error'] !== UPLOAD_ERR_OK) {
    header('Content-Type: application/json');
    echo json_encode(['error' => '文件上传失败']);
    exit;
}

// 检查文件类型
$allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
if (!in_array($file['type'], $allowed_types)) {
    header('Content-Type: application/json');
    echo json_encode(['error' => '只允许上传JPG、PNG和GIF格式的图片']);
    exit;
}

// 检查文件大小（限制为2MB）
if ($file['size'] > 2 * 1024 * 1024) {
    header('Content-Type: application/json');
    echo json_encode(['error' => '图片大小不能超过2MB']);
    exit;
}

// 生成唯一的文件名
$extension = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = uniqid() . '.' . $extension;
$upload_dir = '../images/';

// 确保上传目录存在
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// 移动文件到目标目录
if (move_uploaded_file($file['tmp_name'], $upload_dir . $filename)) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'url' => 'images/' . $filename
    ]);
} else {
    header('Content-Type: application/json');
    echo json_encode(['error' => '文件保存失败']);
} 